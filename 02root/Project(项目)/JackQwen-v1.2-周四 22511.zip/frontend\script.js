// API基础URL
const API_BASE = '';

// 全局状态
let currentSessionId = null;
let isStreaming = false;

// DOM元素（延迟初始化，确保DOM已加载）
let sessionList, chatWindow, messageInput, btnSend, btnNewChat;
let systemPromptInput, btnSavePrompt, promptTemplateSelect, btnSaveTemplate;
let sidebarLeft, sidebarRight, btnToggleLeft, btnToggleRight, btnToggleTheme;
let collapsedBarLeft, collapsedBarRight, btnExpandLeft, btnExpandRight;
let btnNewChatCollapsed, sessionTitleInput, mainContent, body;
let btnToggleThemeCollapsed, btnToggleThemeSidebar;
let templateList, templateSearchInput, templateCategoryFilter, templateSortFilter;
let btnFilterFavorite, btnCreateTemplate, btnExportPrompt, btnImportPrompt;

// 获取DOM元素
function initDOMElements() {
    sessionList = document.getElementById('session-list');
    chatWindow = document.getElementById('chat-window');
    messageInput = document.getElementById('message-input');
    btnSend = document.getElementById('btn-send');
    btnNewChat = document.getElementById('btn-new-chat');
    systemPromptInput = document.getElementById('system-prompt-input');
    btnSavePrompt = document.getElementById('btn-save-prompt');
    promptTemplateSelect = document.getElementById('prompt-template-select');
    btnSaveTemplate = document.getElementById('btn-save-template');
    sidebarLeft = document.getElementById('sidebar-left');
    sidebarRight = document.getElementById('sidebar-right');
    btnToggleLeft = document.getElementById('btn-toggle-left');
    btnToggleRight = document.getElementById('btn-toggle-right');
    btnToggleTheme = document.getElementById('btn-toggle-theme'); // 保留引用，但不再使用
    collapsedBarLeft = document.getElementById('collapsed-bar-left');
    collapsedBarRight = document.getElementById('collapsed-bar-right');
    btnExpandLeft = document.getElementById('btn-expand-left');
    btnExpandRight = document.getElementById('btn-expand-right');
    btnNewChatCollapsed = document.getElementById('btn-new-chat-collapsed');
    sessionTitleInput = document.getElementById('session-title-input');
    mainContent = document.querySelector('.main-content');
    body = document.body;
    btnToggleThemeCollapsed = document.getElementById('btn-toggle-theme-collapsed');
    btnToggleThemeSidebar = document.getElementById('btn-toggle-theme-sidebar');
    templateList = document.getElementById('template-list');
    templateSearchInput = document.getElementById('template-search-input');
    templateCategoryFilter = document.getElementById('template-category-filter');
    templateSortFilter = document.getElementById('template-sort-filter');
    btnFilterFavorite = document.getElementById('btn-filter-favorite');
    btnCreateTemplate = document.getElementById('btn-create-template');
    btnExportPrompt = document.getElementById('btn-export-prompt');
    btnImportPrompt = document.getElementById('btn-import-prompt');
    
    // 检查关键元素是否存在
    if (!sessionList || !chatWindow || !messageInput || !btnSend || !btnNewChat) {
        console.error('关键DOM元素未找到！', {
            sessionList: !!sessionList,
            chatWindow: !!chatWindow,
            messageInput: !!messageInput,
            btnSend: !!btnSend,
            btnNewChat: !!btnNewChat
        });
        setTimeout(initDOMElements, 100); // 重试
        return false;
    }
    return true;
}

// 初始化
document.addEventListener('DOMContentLoaded', async () => {
    console.log('开始初始化...');
    try {
        // 初始化DOM元素
        console.log('初始化DOM元素...');
        if (!initDOMElements()) {
            console.error('DOM元素初始化失败，将在100ms后重试');
            setTimeout(() => {
                if (initDOMElements()) {
                    console.log('DOM元素初始化成功（重试）');
                    startApp();
                } else {
                    console.error('DOM元素初始化失败（重试后）');
                    alert('页面加载失败，请刷新页面重试');
                }
            }, 100);
            return;
        }
        
        startApp();
    } catch (error) {
        console.error('初始化失败:', error);
        console.error('错误堆栈:', error.stack);
        alert('页面初始化失败，请刷新页面重试。错误: ' + error.message);
    }
});

// 启动应用
async function startApp() {
    try {
        console.log('加载主题和侧边栏状态...');
        // 加载保存的主题和侧边栏状态
        loadTheme();
        loadSidebarState();
        
        console.log('加载会话列表...');
        await loadSessions();
        console.log('加载提示词模板...');
        await loadTemplateCategories();
        await loadPromptTemplates();
        
        // 如果没有会话，自动创建第一个
        if (currentSessionId === null) {
            console.log('没有会话，创建新会话...');
            await createNewSession();
        }
        
        console.log('绑定事件监听器...');
        // 绑定事件
        if (btnSend) {
            btnSend.addEventListener('click', sendMessage);
            console.log('✓ btnSend 事件绑定成功');
        } else {
            console.error('✗ btnSend 未找到');
        }
        
        if (btnNewChat) {
            btnNewChat.addEventListener('click', createNewSession);
            console.log('✓ btnNewChat 事件绑定成功');
        } else {
            console.error('✗ btnNewChat 未找到');
        }
        
        if (btnSavePrompt) btnSavePrompt.addEventListener('click', saveSystemPrompt);
        if (btnCreateTemplate) btnCreateTemplate.addEventListener('click', showCreateTemplateModal);
        if (templateSearchInput) templateSearchInput.addEventListener('input', filterTemplates);
        if (templateCategoryFilter) templateCategoryFilter.addEventListener('change', filterTemplates);
        if (templateSortFilter) templateSortFilter.addEventListener('change', filterTemplates);
        if (btnFilterFavorite) btnFilterFavorite.addEventListener('click', toggleFavoriteFilter);
        if (btnExportPrompt) btnExportPrompt.addEventListener('click', exportPromptAsMarkdown);
        if (btnImportPrompt) btnImportPrompt.addEventListener('click', importPromptFromMarkdown);
        
        if (btnToggleLeft) {
            btnToggleLeft.addEventListener('click', () => toggleSidebar('left'));
            console.log('✓ btnToggleLeft 事件绑定成功');
        } else {
            console.error('✗ btnToggleLeft 未找到');
        }
        
        if (btnToggleRight) {
            btnToggleRight.addEventListener('click', () => toggleSidebar('right'));
            console.log('✓ btnToggleRight 事件绑定成功');
        } else {
            console.error('✗ btnToggleRight 未找到');
        }
        
        if (btnToggleThemeCollapsed) btnToggleThemeCollapsed.addEventListener('click', toggleTheme);
        if (btnToggleThemeSidebar) btnToggleThemeSidebar.addEventListener('click', toggleTheme);
        if (btnExpandLeft) btnExpandLeft.addEventListener('click', () => toggleSidebar('left'));
        if (btnExpandRight) btnExpandRight.addEventListener('click', () => toggleSidebar('right'));
        if (btnNewChatCollapsed) btnNewChatCollapsed.addEventListener('click', createNewSession);
        
        // 会话标题编辑
        if (sessionTitleInput) {
            sessionTitleInput.addEventListener('blur', saveSessionTitle);
            sessionTitleInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    sessionTitleInput.blur();
                }
            });
        }
        
        if (messageInput) {
            messageInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                }
            });
            console.log('✓ messageInput 事件绑定成功');
        } else {
            console.error('✗ messageInput 未找到');
        }
        
        // 监听侧边栏状态变化，更新主内容区padding
        updateMainContentPadding();
        
        // 设置输入框自动高度
        setupInputAutoHeight();
        
        console.log('✓ 初始化完成！');
        console.log('当前会话ID:', currentSessionId);
    } catch (error) {
        console.error('启动应用失败:', error);
        console.error('错误堆栈:', error.stack);
        alert('应用启动失败: ' + error.message);
    }
}

// 加载会话列表
async function loadSessions() {
    try {
        if (!sessionList) {
            console.error('loadSessions: sessionList 未找到');
            return;
        }
        
        console.log('请求会话列表:', `${API_BASE}/api/sessions`);
        const response = await fetch(`${API_BASE}/api/sessions`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        const sessions = data.sessions || [];
        
        console.log('收到会话列表:', sessions.length, '个会话');
        
        sessionList.innerHTML = '';
        
        if (sessions.length === 0) {
            sessionList.innerHTML = '<div style="padding: 20px; color: #aaa; text-align: center;">暂无会话</div>';
            return;
        }
        
        sessions.forEach(session => {
            const sessionItem = createSessionItem(session);
            sessionList.appendChild(sessionItem);
        });
        
        // 如果有当前会话，高亮显示
        if (currentSessionId) {
            highlightSession(currentSessionId);
        }
    } catch (error) {
        console.error('加载会话列表失败:', error);
        console.error('错误详情:', error.message);
        if (sessionList) {
            sessionList.innerHTML = '<div style="padding: 20px; color: red; text-align: center;">加载会话失败: ' + error.message + '</div>';
        }
    }
}

// 创建会话项
function createSessionItem(session) {
    const div = document.createElement('div');
    div.className = 'session-item';
    div.dataset.sessionId = session.id;
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'session-item-content';
    
    const title = document.createElement('div');
    title.className = 'session-item-title';
    title.textContent = session.title || '新对话';
    title.dataset.editable = 'true';
    
    const time = document.createElement('div');
    time.className = 'session-item-time';
    time.textContent = formatTime(session.created_at);
    
    contentDiv.appendChild(title);
    contentDiv.appendChild(time);
    
    // 添加按钮容器
    const btnContainer = document.createElement('div');
    btnContainer.className = 'session-item-actions';
    
    // 添加编辑按钮
    const editBtn = document.createElement('button');
    editBtn.className = 'session-edit-btn';
    editBtn.innerHTML = '✏️';
    editBtn.title = '编辑名称';
    editBtn.onclick = (e) => {
        e.stopPropagation();
        editSessionTitle(session.id, title);
    };
    
    // 添加删除按钮
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'session-delete-btn';
    deleteBtn.innerHTML = '🗑️';
    deleteBtn.title = '删除会话';
    deleteBtn.onclick = (e) => {
        e.stopPropagation();
        deleteSession(session.id);
    };
    
    btnContainer.appendChild(editBtn);
    btnContainer.appendChild(deleteBtn);
    
    div.appendChild(contentDiv);
    div.appendChild(btnContainer);
    
    div.addEventListener('click', (e) => {
        // 如果点击的是按钮，不切换会话
        if (e.target.closest('.session-item-actions')) {
            return;
        }
        switchSession(session.id);
    });
    
    return div;
}

// 格式化时间
function formatTime(timestamp) {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}小时前`;
    if (diff < 604800000) return `${Math.floor(diff / 86400000)}天前`;
    
    return date.toLocaleDateString('zh-CN');
}

// 高亮会话
function highlightSession(sessionId) {
    document.querySelectorAll('.session-item').forEach(item => {
        item.classList.remove('active');
        if (parseInt(item.dataset.sessionId) === sessionId) {
            item.classList.add('active');
        }
    });
}

// 创建新会话
async function createNewSession() {
    try {
        console.log('创建新会话...');
        const response = await fetch(`${API_BASE}/api/sessions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                title: '新对话',
                system_prompt: ''
            })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        currentSessionId = data.session_id;
        console.log('✓ 会话创建成功，ID:', currentSessionId);
        
        await loadSessions();
        await switchSession(currentSessionId);
        
        // 清空输入框和system prompt
        if (messageInput) messageInput.value = '';
        if (systemPromptInput) systemPromptInput.value = '';
        if (sessionTitleInput) sessionTitleInput.value = '新对话';
    } catch (error) {
        console.error('创建会话失败:', error);
        console.error('错误详情:', error.message);
        alert('创建会话失败: ' + error.message);
    }
}

// 删除会话
async function deleteSession(sessionId) {
    if (!confirm('确定要删除这个会话吗？删除后无法恢复。')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/api/sessions/${sessionId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            // 如果删除的是当前会话，清空聊天窗口
            if (currentSessionId === sessionId) {
                currentSessionId = null;
                if (chatWindow) chatWindow.innerHTML = '';
                showWelcomeMessage();
                if (systemPromptInput) systemPromptInput.value = '';
                if (sessionTitleInput) sessionTitleInput.value = '';
            }
            // 重新加载会话列表
            await loadSessions();
        } else {
            throw new Error('删除失败');
        }
    } catch (error) {
        console.error('删除会话失败:', error);
        alert('删除会话失败，请重试');
    }
}

// 切换会话
async function switchSession(sessionId) {
    currentSessionId = sessionId;
    highlightSession(sessionId);
    
    // 加载会话信息和消息
    try {
        const [sessionResponse, messagesResponse] = await Promise.all([
            fetch(`${API_BASE}/api/sessions/${sessionId}`),
            fetch(`${API_BASE}/api/sessions/${sessionId}/messages`)
        ]);
        
        const sessionData = await sessionResponse.json();
        const messagesData = await messagesResponse.json();
        
        // 更新会话标题输入框
        if (sessionTitleInput) {
            sessionTitleInput.value = sessionData.title || '新对话';
        }
        
        // 更新system prompt
        if (systemPromptInput) {
            systemPromptInput.value = sessionData.system_prompt || '';
        }
        
        // 清空并加载消息
        chatWindow.innerHTML = '';
        
        if (messagesData.messages && messagesData.messages.length > 0) {
            messagesData.messages.forEach(msg => {
                appendMessage(msg.role, msg.content, msg.id);
            });
        } else {
            showWelcomeMessage();
        }
        
        // 滚动到底部
        scrollToBottom();
    } catch (error) {
        console.error('加载会话失败:', error);
        alert('加载会话失败，请重试');
    }
}

// 显示欢迎消息
function showWelcomeMessage() {
    let innerContainer = chatWindow.querySelector('.chat-window-inner');
    if (!innerContainer) {
        innerContainer = document.createElement('div');
        innerContainer.className = 'chat-window-inner';
        chatWindow.innerHTML = '';
        chatWindow.appendChild(innerContainer);
    }
    
    let messagesContainer = innerContainer.querySelector('.messages-container');
    if (!messagesContainer) {
        messagesContainer = document.createElement('div');
        messagesContainer.className = 'messages-container';
        innerContainer.innerHTML = '';
        innerContainer.appendChild(messagesContainer);
    }
    
    messagesContainer.innerHTML = `
        <div class="welcome-message">
            <p>👋 欢迎使用AI聊天机器人！</p>
            <p>开始对话吧！</p>
        </div>
    `;
}

// 发送消息
async function sendMessage() {
    if (isStreaming) {
        return;
    }
    
    if (!messageInput) {
        console.error('messageInput 未找到');
        return;
    }
    
    const content = messageInput.value.trim();
    if (!content) {
        return;
    }
    
    if (!currentSessionId) {
        await createNewSession();
    }
    
    // 显示用户消息（临时，等待保存后更新）
    const userMsgDiv = appendMessage('user', content);
    if (userMsgDiv) {
        userMsgDiv.setAttribute('data-temp-id', 'true');
    }
    
    // 清空输入框
    messageInput.value = '';
    messageInput.style.height = 'auto';
    
    // 禁用发送按钮
    if (btnSend) btnSend.disabled = true;
    isStreaming = true;
    
    // 创建AI消息占位符（临时，等待保存后更新）
    const assistantDiv = appendMessage('assistant', '');
    if (!assistantDiv) {
        console.error('无法创建AI消息占位符');
        if (btnSend) btnSend.disabled = false;
        isStreaming = false;
        return;
    }
    assistantDiv.setAttribute('data-temp-id', 'true');
    const assistantContent = assistantDiv.querySelector('.message-content');
    if (!assistantContent) {
        console.error('无法找到assistantContent');
        return;
    }
    
    try {
        // 获取当前会话的所有消息
        const messagesResponse = await fetch(`${API_BASE}/api/sessions/${currentSessionId}/messages`);
        const messagesData = await messagesResponse.json();
        const historyMessages = (messagesData.messages || []).map(msg => ({
            role: msg.role,
            content: msg.content
        }));
        
        // 添加新消息
        historyMessages.push({
            role: 'user',
            content: content
        });
        
        // 获取system prompt
        const sessionResponse = await fetch(`${API_BASE}/api/sessions/${currentSessionId}`);
        const sessionData = await sessionResponse.json();
        const systemPrompt = (systemPromptInput && systemPromptInput.value.trim()) || sessionData.system_prompt || '';
        
        // 发送请求
        const response = await fetch(`${API_BASE}/api/chat`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                session_id: currentSessionId,
                messages: [{ role: 'user', content: content }],
                system_prompt: systemPrompt
            })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        // 处理流式响应
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        let fullContent = '';
        
        while (true) {
            const { done, value } = await reader.read();
            
            if (done) {
                break;
            }
            
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop(); // 保留最后一个不完整的行
            
            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    const data = line.slice(6);
                    
                    if (data === '[DONE]') {
                        break;
                    }
                    
                    try {
                        const json = JSON.parse(data);
                        if (json.error) {
                            assistantContent.innerHTML = `<p style="color: red;">${json.error}</p>`;
                            break;
                        }
                        if (json.content) {
                            fullContent += json.content;
                            // 使用renderMath渲染Markdown和数学公式
                            assistantContent.innerHTML = renderMath(fullContent);
                            assistantContent.dataset.needsMathRender = 'true';
                            scrollToBottom();
                        }
                    } catch (e) {
                        console.error('解析响应数据失败:', e);
                    }
                }
            }
        }
        
        // 处理剩余的buffer
        if (buffer.startsWith('data: ')) {
            const data = buffer.slice(6);
            if (data !== '[DONE]') {
                try {
                    const json = JSON.parse(data);
                    if (json.content) {
                        fullContent += json.content;
                        assistantContent.innerHTML = renderMath(fullContent);
                        assistantContent.dataset.needsMathRender = 'true';
                    }
                } catch (e) {
                    console.error('解析响应数据失败:', e);
                }
            }
        }
        
        scrollToBottom();
        
        // 流式传输完成后，重新加载消息以获取messageId并更新DOM
        if (fullContent.trim()) {
            setTimeout(async () => {
                try {
                    const messagesResponse = await fetch(`${API_BASE}/api/sessions/${currentSessionId}/messages`);
                    const messagesData = await messagesResponse.json();
                    if (messagesData.messages && messagesData.messages.length > 0) {
                        // 找到最后两条消息（用户消息和AI回复）
                        const lastTwoMessages = messagesData.messages.slice(-2);
                        const tempMessages = document.querySelectorAll('[data-temp-id]');
                        
                        lastTwoMessages.forEach((msg, index) => {
                            if (index < tempMessages.length) {
                                const tempMsg = tempMessages[index];
                                tempMsg.id = `msg-${msg.id}`;
                                tempMsg.dataset.messageId = msg.id;
                                tempMsg.removeAttribute('data-temp-id');
                                
                                // 更新内容（AI消息需要重新渲染）
                                if (msg.role === 'assistant') {
                                    const contentDiv = tempMsg.querySelector('.message-content');
                                    contentDiv.innerHTML = renderMath(msg.content);
                                    contentDiv.dataset.needsMathRender = 'true';
                                }
                                
                                // 添加操作按钮（如果还没有）
                                if (!tempMsg.querySelector('.message-actions')) {
                                    const container = tempMsg.querySelector('.message-container');
                                    if (container) {
                                        const actionsDiv = document.createElement('div');
                                        actionsDiv.className = 'message-actions';
                                        
                                        const copyBtn = document.createElement('button');
                                        copyBtn.className = 'msg-btn msg-btn-copy';
                                        copyBtn.title = '复制';
                                        copyBtn.innerHTML = '📋';
                                        copyBtn.onclick = () => copyMessage(msg.id, msg.content);
                                        
                                        const editBtn = document.createElement('button');
                                        editBtn.className = 'msg-btn msg-btn-edit';
                                        editBtn.title = '编辑';
                                        editBtn.innerHTML = '✏️';
                                        editBtn.onclick = () => editMessage(msg.id, msg.content, msg.role);
                                        
                                        const deleteBtn = document.createElement('button');
                                        deleteBtn.className = 'msg-btn msg-btn-delete';
                                        deleteBtn.title = '删除';
                                        deleteBtn.innerHTML = '🗑️';
                                        deleteBtn.onclick = () => deleteMessage(msg.id);
                                        
                                        actionsDiv.appendChild(copyBtn);
                                        actionsDiv.appendChild(editBtn);
                                        actionsDiv.appendChild(deleteBtn);
                                        container.appendChild(actionsDiv);
                                    }
                                }
                            }
                        });
                        
                        // 刷新会话列表以更新标题
                        await loadSessions();
                    }
                } catch (e) {
                    console.error('更新消息ID失败:', e);
                }
            }, 500);
        }
        
    } catch (error) {
        console.error('发送消息失败:', error);
        if (assistantContent) {
            assistantContent.innerHTML = `<p style="color: red;">发送失败: ${error.message}</p>`;
        }
    } finally {
        if (btnSend) btnSend.disabled = false;
        isStreaming = false;
        if (messageInput) messageInput.focus();
    }
}

// 渲染数学公式（KaTeX）
function renderMath(content) {
    // 使用marked渲染Markdown
    let html = marked.parse(content);
    
    // 延迟渲染KaTeX，确保DOM已更新
    setTimeout(() => {
        if (typeof renderMathInElement !== 'undefined') {
            const elements = document.querySelectorAll('.message-content');
            elements.forEach(el => {
                if (el.dataset.needsMathRender) {
                    renderMathInElement(el, {
                        delimiters: [
                            {left: '$$', right: '$$', display: true},
                            {left: '$', right: '$', display: false},
                            {left: '\\[', right: '\\]', display: true},
                            {left: '\\(', right: '\\)', display: false}
                        ],
                        throwOnError: false
                    });
                    delete el.dataset.needsMathRender;
                }
            });
        }
    }, 0);
    
    return html;
}

// 添加消息到聊天窗口
function appendMessage(role, content, messageId = null) {
    // 确保chat-window-inner容器存在
    let innerContainer = chatWindow.querySelector('.chat-window-inner');
    if (!innerContainer) {
        innerContainer = document.createElement('div');
        innerContainer.className = 'chat-window-inner';
        chatWindow.innerHTML = '';
        chatWindow.appendChild(innerContainer);
    }
    
    // 确保messages-container容器存在
    let messagesContainer = innerContainer.querySelector('.messages-container');
    if (!messagesContainer) {
        messagesContainer = document.createElement('div');
        messagesContainer.className = 'messages-container';
        innerContainer.appendChild(messagesContainer);
    }
    
    // 如果欢迎消息还在，先移除
    const welcomeMsg = messagesContainer.querySelector('.welcome-message');
    if (welcomeMsg) {
        welcomeMsg.remove();
    }
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}`;
    if (messageId) {
        messageDiv.id = `msg-${messageId}`;
        messageDiv.dataset.messageId = messageId;
    }
    
    // 消息容器
    const messageContainer = document.createElement('div');
    messageContainer.className = 'message-container';
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    
    if (role === 'assistant' && content) {
        // 使用marked渲染Markdown，并标记需要渲染数学公式
        contentDiv.innerHTML = renderMath(content);
        contentDiv.dataset.needsMathRender = 'true';
    } else if (role === 'assistant' && !content) {
        // 空内容，显示加载指示器
        contentDiv.innerHTML = '<span class="typing-indicator"></span>';
    } else {
        // 用户消息，直接显示文本
        contentDiv.textContent = content;
    }
    
    messageContainer.appendChild(contentDiv);
    
    // 添加操作按钮（仅在消息有ID时显示，即已保存的消息）
    if (messageId) {
        const actionsDiv = document.createElement('div');
        actionsDiv.className = 'message-actions';
        
        // 复制按钮
        const copyBtn = document.createElement('button');
        copyBtn.className = 'msg-btn msg-btn-copy';
        copyBtn.title = '复制';
        copyBtn.innerHTML = '📋';
        copyBtn.onclick = () => copyMessage(messageId, content);
        
        // 编辑按钮
        const editBtn = document.createElement('button');
        editBtn.className = 'msg-btn msg-btn-edit';
        editBtn.title = '编辑';
        editBtn.innerHTML = '✏️';
        editBtn.onclick = () => editMessage(messageId, content, role);
        
        // 删除按钮
        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'msg-btn msg-btn-delete';
        deleteBtn.title = '删除';
        deleteBtn.innerHTML = '🗑️';
        deleteBtn.onclick = () => deleteMessage(messageId);
        
        actionsDiv.appendChild(copyBtn);
        actionsDiv.appendChild(editBtn);
        actionsDiv.appendChild(deleteBtn);
        
        messageContainer.appendChild(actionsDiv);
    }
    
    messageDiv.appendChild(messageContainer);
    
    // 添加到messages-container容器（已经在函数开头确保存在）
    messagesContainer.appendChild(messageDiv);
    
    scrollToBottom();
    
    return messageDiv;
}

// 滚动到底部
function scrollToBottom() {
    if (chatWindow) {
        chatWindow.scrollTop = chatWindow.scrollHeight;
    }
}

// 保存system prompt
async function saveSystemPrompt() {
    if (!currentSessionId) {
        alert('请先选择或创建一个会话');
        return;
    }
    
    if (!systemPromptInput) {
        console.error('systemPromptInput 未找到');
        return;
    }
    
    const systemPrompt = systemPromptInput.value.trim();
    
    try {
        const response = await fetch(`${API_BASE}/api/sessions/${currentSessionId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                system_prompt: systemPrompt
            })
        });
        
        if (response.ok) {
            alert('保存成功');
        } else {
            throw new Error('保存失败');
        }
    } catch (error) {
        console.error('保存system prompt失败:', error);
        alert('保存失败，请重试');
    }
}

// 复制消息
async function copyMessage(messageId, content) {
    try {
        await navigator.clipboard.writeText(content);
        // 显示复制成功提示
        const btn = document.querySelector(`#msg-${messageId} .msg-btn-copy`);
        if (btn) {
            const original = btn.innerHTML;
            btn.innerHTML = '✓';
            btn.style.color = '#4a9eff';
            setTimeout(() => {
                btn.innerHTML = original;
                btn.style.color = '';
            }, 1000);
        }
    } catch (err) {
        console.error('复制失败:', err);
        alert('复制失败，请手动复制');
    }
}

// 删除消息
async function deleteMessage(messageId) {
    if (!confirm('确定要删除这条消息吗？')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/api/messages/${messageId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            // 从DOM中移除消息
            const messageDiv = document.getElementById(`msg-${messageId}`);
            if (messageDiv) {
                messageDiv.style.transition = 'opacity 0.3s';
                messageDiv.style.opacity = '0';
                setTimeout(() => {
                    messageDiv.remove();
                    // 如果聊天窗口为空，显示欢迎消息
                    const innerContainer = chatWindow.querySelector('.chat-window-inner');
                    if (innerContainer) {
                        const messagesContainer = innerContainer.querySelector('.messages-container');
                        if (messagesContainer && messagesContainer.children.length === 0) {
                            showWelcomeMessage();
                        }
                    }
                }, 300);
            }
        } else {
            throw new Error('删除失败');
        }
    } catch (error) {
        console.error('删除消息失败:', error);
        alert('删除失败，请重试');
    }
}

// 编辑消息
function editMessage(messageId, content, role) {
    const messageDiv = document.getElementById(`msg-${messageId}`);
    if (!messageDiv) return;
    
    const messageContainer = messageDiv.querySelector('.message-container');
    if (!messageContainer) return;
    
    const contentDiv = messageContainer.querySelector('.message-content');
    if (!contentDiv) return;
    
    // 如果已经在编辑模式，先取消
    const existingEdit = messageContainer.querySelector('.message-edit-input');
    if (existingEdit) {
        cancelEdit(messageDiv, messageContainer, contentDiv, content, role);
    }
    
    // 创建编辑框
    const editTextarea = document.createElement('textarea');
    editTextarea.className = 'message-edit-input';
    editTextarea.value = content;
    editTextarea.rows = Math.max(3, content.split('\n').length);
    
    // 创建按钮容器
    const btnContainer = document.createElement('div');
    btnContainer.className = 'message-edit-actions';
    
    const saveBtn = document.createElement('button');
    saveBtn.className = 'msg-btn-edit-save';
    saveBtn.textContent = '保存';
    saveBtn.onclick = async () => {
        const newContent = editTextarea.value.trim();
        if (newContent === content) {
            // 内容未改变，取消编辑
            cancelEdit(messageDiv, messageContainer, contentDiv, content, role);
            return;
        }
        
        try {
            const response = await fetch(`${API_BASE}/api/messages/${messageId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    content: newContent
                })
            });
            
            if (response.ok) {
                // 更新内容显示
                if (role === 'assistant') {
                    contentDiv.innerHTML = renderMath(newContent);
                    contentDiv.dataset.needsMathRender = 'true';
                } else {
                    contentDiv.textContent = newContent;
                }
                // 移除编辑框和按钮
                editTextarea.remove();
                btnContainer.remove();
                // 显示内容
                contentDiv.style.display = '';
            } else {
                throw new Error('更新失败');
            }
        } catch (error) {
            console.error('更新消息失败:', error);
            alert('更新失败，请重试');
        }
    };
    
    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'msg-btn-edit-cancel';
    cancelBtn.textContent = '取消';
    cancelBtn.onclick = () => {
        cancelEdit(messageDiv, messageContainer, contentDiv, content, role);
    };
    
    btnContainer.appendChild(saveBtn);
    btnContainer.appendChild(cancelBtn);
    
    // 隐藏内容，插入编辑框和按钮
    contentDiv.style.display = 'none';
    messageContainer.insertBefore(editTextarea, contentDiv);
    messageContainer.insertBefore(btnContainer, contentDiv);
    
    // 聚焦并选中文本
    setTimeout(() => {
        editTextarea.focus();
        editTextarea.select();
    }, 0);
}

// 取消编辑
function cancelEdit(messageDiv, messageContainer, contentDiv, originalContent, role) {
    const editTextarea = messageContainer.querySelector('.message-edit-input');
    const btnContainer = messageContainer.querySelector('.message-edit-actions');
    
    if (editTextarea) editTextarea.remove();
    if (btnContainer) btnContainer.remove();
    
    contentDiv.style.display = '';
}

// 编辑会话标题
async function editSessionTitle(sessionId, titleElement) {
    const currentTitle = titleElement.textContent;
    
    // 创建输入框
    const input = document.createElement('input');
    input.type = 'text';
    input.value = currentTitle;
    input.className = 'session-title-edit-input';
    input.style.width = '100%';
    input.style.padding = '4px 8px';
    input.style.border = '1px solid #4a9eff';
    input.style.borderRadius = '4px';
    input.style.background = '#2c2c2c';
    input.style.color = '#fff';
    input.style.fontSize = '14px';
    
    // 替换标题元素
    const parent = titleElement.parentElement;
    parent.replaceChild(input, titleElement);
    input.focus();
    input.select();
    
    const saveEdit = async () => {
        const newTitle = input.value.trim() || '新对话';
        if (newTitle === currentTitle) {
            parent.replaceChild(titleElement, input);
            return;
        }
        
        try {
            const response = await fetch(`${API_BASE}/api/sessions/${sessionId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    title: newTitle
                })
            });
            
            if (response.ok) {
                titleElement.textContent = newTitle;
                parent.replaceChild(titleElement, input);
                await loadSessions(); // 刷新列表
            } else {
                throw new Error('更新失败');
            }
        } catch (error) {
            console.error('更新会话标题失败:', error);
            alert('更新失败，请重试');
            parent.replaceChild(titleElement, input);
        }
    };
    
    const cancelEdit = () => {
        parent.replaceChild(titleElement, input);
    };
    
    input.addEventListener('blur', saveEdit);
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            input.blur();
        } else if (e.key === 'Escape') {
            e.preventDefault();
            cancelEdit();
        }
    });
}

// 模板筛选状态
let templateFilterState = {
    search: '',
    category: '',
    isFavorite: false,
    sortBy: 'created_at'
};

// 加载模板分类列表
async function loadTemplateCategories() {
    try {
        const response = await fetch(`${API_BASE}/api/prompt-templates/categories`);
        if (response.ok) {
            const data = await response.json();
            const categories = data.categories || [];
            
            if (templateCategoryFilter) {
                const currentValue = templateCategoryFilter.value;
                templateCategoryFilter.innerHTML = '<option value="">全部分类</option>';
                categories.forEach(cat => {
                    const option = document.createElement('option');
                    option.value = cat;
                    option.textContent = cat;
                    templateCategoryFilter.appendChild(option);
                });
                templateCategoryFilter.value = currentValue;
            }
        }
    } catch (error) {
        console.error('加载分类失败:', error);
    }
}

// 加载提示词模板（卡片列表）
async function loadPromptTemplates() {
    try {
        if (!templateList) {
            console.error('templateList 未找到');
            return;
        }
        
        const params = new URLSearchParams();
        if (templateFilterState.category) {
            params.append('category', templateFilterState.category);
        }
        if (templateFilterState.isFavorite) {
            params.append('is_favorite', 'true');
        }
        if (templateFilterState.search) {
            params.append('search', templateFilterState.search);
        }
        params.append('sort_by', templateFilterState.sortBy);
        
        const url = `${API_BASE}/api/prompt-templates?${params.toString()}`;
        console.log('请求提示词模板:', url);
        
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        const templates = data.templates || [];
        
        console.log('收到提示词模板:', templates.length, '个模板');
        
        // 渲染模板卡片
        renderTemplateCards(templates);
        
        console.log('✓ 提示词模板加载完成');
    } catch (error) {
        console.error('加载提示词模板失败:', error);
        console.error('错误详情:', error.message);
        if (templateList) {
            templateList.innerHTML = '<div class="template-empty">加载失败，请刷新重试</div>';
        }
    }
}

// 渲染模板卡片
function renderTemplateCards(templates) {
    if (!templateList) return;
    
    if (templates.length === 0) {
        templateList.innerHTML = '<div class="template-empty">暂无模板</div>';
        return;
    }
    
    templateList.innerHTML = '';
    
    templates.forEach(template => {
        const card = createTemplateCard(template);
        templateList.appendChild(card);
    });
}

// 创建模板卡片
function createTemplateCard(template) {
    const card = document.createElement('div');
    card.className = 'template-card';
    card.dataset.templateId = template.id;
    
    // 预览内容（前100个字符）
    const preview = template.content.length > 100 
        ? template.content.substring(0, 100) + '...' 
        : template.content;
    
    card.innerHTML = `
        <div class="template-card-header">
            <div class="template-card-title">
                <span class="template-name">${escapeHtml(template.name)}</span>
                ${template.category ? `<span class="template-category">${escapeHtml(template.category)}</span>` : ''}
            </div>
            <div class="template-card-actions">
                <button class="template-btn template-btn-favorite ${template.is_favorite ? 'active' : ''}" 
                        data-template-id="${template.id}" 
                        title="${template.is_favorite ? '取消收藏' : '收藏'}">
                    ${template.is_favorite ? '⭐' : '☆'}
                </button>
                <button class="template-btn template-btn-apply" 
                        data-template-id="${template.id}" 
                        title="应用模板">✓</button>
                <button class="template-btn template-btn-copy" 
                        data-template-id="${template.id}" 
                        title="复制内容">📋</button>
                <button class="template-btn template-btn-edit" 
                        data-template-id="${template.id}" 
                        title="编辑">✏️</button>
                <button class="template-btn template-btn-delete" 
                        data-template-id="${template.id}" 
                        title="删除">🗑️</button>
            </div>
        </div>
        <div class="template-card-preview" title="${escapeHtml(template.content)}">
            ${escapeHtml(preview)}
        </div>
        <div class="template-card-footer">
            <span class="template-stats">使用 ${template.use_count || 0} 次</span>
            ${template.last_used_at ? `<span class="template-last-used">${formatTime(template.last_used_at)}</span>` : ''}
        </div>
    `;
    
    // 绑定事件
    card.querySelector('.template-btn-apply').addEventListener('click', () => applyTemplate(template.id));
    card.querySelector('.template-btn-copy').addEventListener('click', () => copyTemplateContent(template.content));
    card.querySelector('.template-btn-edit').addEventListener('click', () => showEditTemplateModal(template));
    card.querySelector('.template-btn-delete').addEventListener('click', () => deleteTemplate(template.id));
    card.querySelector('.template-btn-favorite').addEventListener('click', () => toggleTemplateFavorite(template.id));
    
    return card;
}

// HTML转义函数
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// 应用模板
async function applyTemplate(templateId) {
    try {
        // 记录使用
        await fetch(`${API_BASE}/api/prompt-templates/${templateId}/use`, {
            method: 'POST'
        });
        
        // 加载模板内容
        const response = await fetch(`${API_BASE}/api/prompt-templates/${templateId}`);
        const template = await response.json();
        
        if (systemPromptInput) {
            systemPromptInput.value = template.content;
        }
        
        // 刷新模板列表以更新使用统计
        await loadPromptTemplates();
    } catch (error) {
        console.error('应用模板失败:', error);
        alert('应用模板失败，请重试');
    }
}

// 复制模板内容
async function copyTemplateContent(content) {
    try {
        await navigator.clipboard.writeText(content);
        alert('模板内容已复制到剪贴板');
    } catch (error) {
        console.error('复制失败:', error);
        alert('复制失败，请手动复制');
    }
}

// 切换模板收藏状态
async function toggleTemplateFavorite(templateId) {
    try {
        const response = await fetch(`${API_BASE}/api/prompt-templates/${templateId}/favorite`, {
            method: 'POST'
        });
        
        if (response.ok) {
            const data = await response.json();
            // 更新卡片中的收藏按钮
            const btn = document.querySelector(`.template-btn-favorite[data-template-id="${templateId}"]`);
            if (btn) {
                btn.textContent = data.is_favorite ? '⭐' : '☆';
                btn.classList.toggle('active', data.is_favorite);
                btn.title = data.is_favorite ? '取消收藏' : '收藏';
            }
        }
    } catch (error) {
        console.error('切换收藏状态失败:', error);
        alert('操作失败，请重试');
    }
}

// 删除模板
async function deleteTemplate(templateId) {
    if (!confirm('确定要删除这个模板吗？删除后无法恢复。')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/api/prompt-templates/${templateId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            await loadPromptTemplates();
            await loadTemplateCategories();
        } else {
            throw new Error('删除失败');
        }
    } catch (error) {
        console.error('删除模板失败:', error);
        alert('删除失败，请重试');
    }
}

// 筛选模板
function filterTemplates() {
    if (templateSearchInput) {
        templateFilterState.search = templateSearchInput.value.trim();
    }
    if (templateCategoryFilter) {
        templateFilterState.category = templateCategoryFilter.value;
    }
    if (templateSortFilter) {
        templateFilterState.sortBy = templateSortFilter.value;
    }
    loadPromptTemplates();
}

// 切换收藏筛选
let favoriteFilterActive = false;
function toggleFavoriteFilter() {
    favoriteFilterActive = !favoriteFilterActive;
    templateFilterState.isFavorite = favoriteFilterActive;
    
    if (btnFilterFavorite) {
        btnFilterFavorite.classList.toggle('active', favoriteFilterActive);
    }
    
    loadPromptTemplates();
}

// 显示创建模板弹窗
function showCreateTemplateModal() {
    const content = systemPromptInput ? systemPromptInput.value.trim() : '';
    showTemplateModal('create', {
        name: '',
        content: content,
        category: ''
    });
}

// 显示编辑模板弹窗
function showEditTemplateModal(template) {
    showTemplateModal('edit', template);
}

// 显示模板编辑/创建弹窗
function showTemplateModal(mode, template) {
    const modal = document.createElement('div');
    modal.className = 'template-modal';
    modal.innerHTML = `
        <div class="template-modal-content">
            <div class="template-modal-header">
                <h3>${mode === 'create' ? '新建模板' : '编辑模板'}</h3>
                <button class="template-modal-close">&times;</button>
            </div>
            <div class="template-modal-body">
                <div class="form-group">
                    <label>模板名称</label>
                    <input type="text" id="modal-template-name" value="${escapeHtml(template.name)}" placeholder="请输入模板名称" />
                </div>
                <div class="form-group">
                    <label>分类</label>
                    <input type="text" id="modal-template-category" value="${escapeHtml(template.category || '')}" placeholder="请输入分类（可选）" list="category-suggestions" />
                    <datalist id="category-suggestions"></datalist>
                </div>
                <div class="form-group">
                    <label>模板内容</label>
                    <textarea id="modal-template-content" rows="8" placeholder="请输入模板内容">${escapeHtml(template.content)}</textarea>
                </div>
            </div>
            <div class="template-modal-footer">
                <button class="btn-modal-cancel">取消</button>
                <button class="btn-modal-save">保存</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // 加载分类建议
    loadCategorySuggestions();
    
    // 绑定事件
    modal.querySelector('.template-modal-close').addEventListener('click', () => modal.remove());
    modal.querySelector('.btn-modal-cancel').addEventListener('click', () => modal.remove());
    modal.querySelector('.btn-modal-save').addEventListener('click', async () => {
        await saveTemplateFromModal(mode, template.id, modal);
    });
    
    // 点击背景关闭
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.remove();
        }
    });
}

// 加载分类建议
async function loadCategorySuggestions() {
    try {
        const response = await fetch(`${API_BASE}/api/prompt-templates/categories`);
        if (response.ok) {
            const data = await response.json();
            const categories = data.categories || [];
            const datalist = document.getElementById('category-suggestions');
            if (datalist) {
                datalist.innerHTML = '';
                categories.forEach(cat => {
                    const option = document.createElement('option');
                    option.value = cat;
                    datalist.appendChild(option);
                });
            }
        }
    } catch (error) {
        console.error('加载分类建议失败:', error);
    }
}

// 从弹窗保存模板
async function saveTemplateFromModal(mode, templateId, modal) {
    const nameInput = modal.querySelector('#modal-template-name');
    const categoryInput = modal.querySelector('#modal-template-category');
    const contentInput = modal.querySelector('#modal-template-content');
    
    const name = nameInput.value.trim();
    const category = categoryInput.value.trim();
    const content = contentInput.value.trim();
    
    if (!name) {
        alert('请输入模板名称');
        return;
    }
    
    if (!content) {
        alert('请输入模板内容');
        return;
    }
    
    try {
        let response;
        if (mode === 'create') {
            response = await fetch(`${API_BASE}/api/prompt-templates`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name: name,
                    content: content,
                    category: category
                })
            });
        } else {
            response = await fetch(`${API_BASE}/api/prompt-templates/${templateId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name: name,
                    content: content,
                    category: category
                })
            });
        }
        
        if (response.ok) {
            modal.remove();
            await loadPromptTemplates();
            await loadTemplateCategories();
            alert(mode === 'create' ? '模板创建成功！' : '模板更新成功！');
        } else {
            throw new Error('保存失败');
        }
    } catch (error) {
        console.error('保存模板失败:', error);
        alert('保存失败，请重试');
    }
}

// 导出提示词为Markdown
function exportPromptAsMarkdown() {
    if (!systemPromptInput) {
        return;
    }
    
    const content = systemPromptInput.value.trim();
    if (!content) {
        alert('提示词内容为空，无法导出');
        return;
    }
    
    const markdown = `# 系统提示词\n\n${content}`;
    const blob = new Blob([markdown], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `prompt_${new Date().getTime()}.md`;
    a.click();
    URL.revokeObjectURL(url);
}

// 从Markdown导入提示词
function importPromptFromMarkdown() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.md,.txt';
    input.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        try {
            const text = await file.text();
            // 简单解析：移除Markdown标题，提取内容
            const content = text.replace(/^#+\s*.+\n\n?/m, '').trim();
            
            if (systemPromptInput) {
                systemPromptInput.value = content;
                alert('导入成功！');
            }
        } catch (error) {
            console.error('导入失败:', error);
            alert('导入失败，请检查文件格式');
        }
    };
    input.click();
}

// 侧边栏折叠功能
function toggleSidebar(side) {
    if (!sidebarLeft || !sidebarRight || !collapsedBarLeft || !collapsedBarRight) {
        console.error('toggleSidebar: 缺少必要的DOM元素');
        return;
    }
    
    const sidebar = side === 'left' ? sidebarLeft : sidebarRight;
    const collapsedBar = side === 'left' ? collapsedBarLeft : collapsedBarRight;
    
    if (!sidebar || !collapsedBar) {
        console.error('toggleSidebar: 侧边栏元素不存在', side);
        return;
    }
    
    const isCollapsed = sidebar.classList.contains('collapsed');
    
    if (isCollapsed) {
        // 展开侧边栏
        sidebar.classList.remove('collapsed');
        collapsedBar.classList.remove('visible');
        // 立即更新padding（展开时）
        updateMainContentPadding();
        // 延迟移除，等待动画完成
        setTimeout(() => {
            collapsedBar.style.display = 'none';
            // 再次确保padding更新
            updateMainContentPadding();
        }, 300);
    } else {
        // 折叠侧边栏
        collapsedBar.style.display = 'flex';
        // 立即更新padding（折叠时）
        updateMainContentPadding();
        // 强制重排，然后添加visible类触发动画
        setTimeout(() => {
            collapsedBar.classList.add('visible');
            sidebar.classList.add('collapsed');
            // 再次确保padding更新
            updateMainContentPadding();
        }, 10);
    }
    
    // 保存状态到localStorage
    saveSidebarState();
}

// 更新主内容区padding
function updateMainContentPadding() {
    if (!mainContent || !sidebarLeft || !sidebarRight) {
        console.warn('updateMainContentPadding: 缺少必要的DOM元素');
        return;
    }
    
    const leftCollapsed = sidebarLeft.classList.contains('collapsed');
    const rightCollapsed = sidebarRight.classList.contains('collapsed');
    
    let leftPadding = leftCollapsed ? '20px' : '300px'; // 280px + 20px
    let rightPadding = rightCollapsed ? '20px' : '300px';
    
    mainContent.style.paddingLeft = leftPadding;
    mainContent.style.paddingRight = rightPadding;
    mainContent.style.transition = 'padding var(--transition-speed) ease';
}

// 保存会话标题
async function saveSessionTitle() {
    if (!currentSessionId) return;
    
    const newTitle = sessionTitleInput.value.trim() || '新对话';
    
    try {
        const response = await fetch(`${API_BASE}/api/sessions/${currentSessionId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                title: newTitle
            })
        });
        
        if (response.ok) {
            // 更新会话列表中的标题
            await loadSessions();
        } else {
            throw new Error('更新失败');
        }
    } catch (error) {
        console.error('更新会话标题失败:', error);
        // 恢复原值
        const sessionResponse = await fetch(`${API_BASE}/api/sessions/${currentSessionId}`);
        const sessionData = await sessionResponse.json();
        sessionTitleInput.value = sessionData.title || '新对话';
    }
}

// 保存侧边栏状态
function saveSidebarState() {
    const state = {
        leftCollapsed: sidebarLeft.classList.contains('collapsed'),
        rightCollapsed: sidebarRight.classList.contains('collapsed')
    };
    localStorage.setItem('sidebarState', JSON.stringify(state));
}

// 加载侧边栏状态
function loadSidebarState() {
    if (!sidebarLeft || !sidebarRight || !collapsedBarLeft || !collapsedBarRight) {
        console.warn('loadSidebarState: 缺少必要的DOM元素');
        return;
    }
    
    const saved = localStorage.getItem('sidebarState');
    if (saved) {
        try {
            const state = JSON.parse(saved);
            if (state.leftCollapsed) {
                sidebarLeft.classList.add('collapsed');
                collapsedBarLeft.style.display = 'flex';
                setTimeout(() => {
                    collapsedBarLeft.classList.add('visible');
                }, 10);
            } else {
                collapsedBarLeft.style.display = 'none';
            }
            if (state.rightCollapsed) {
                sidebarRight.classList.add('collapsed');
                collapsedBarRight.style.display = 'flex';
                setTimeout(() => {
                    collapsedBarRight.classList.add('visible');
                }, 10);
            } else {
                collapsedBarRight.style.display = 'none';
            }
            // 更新主内容区padding
            setTimeout(() => updateMainContentPadding(), 100);
        } catch (e) {
            console.error('加载侧边栏状态失败:', e);
        }
    } else {
        // 默认隐藏折叠按钮组
        collapsedBarLeft.style.display = 'none';
        collapsedBarRight.style.display = 'none';
        updateMainContentPadding();
    }
}

// 主题切换功能
function toggleTheme() {
    if (!body) {
        body = document.body;
    }
    const isDark = body.classList.contains('theme-dark');
    if (isDark) {
        body.classList.remove('theme-dark');
        body.classList.add('theme-light');
    } else {
        body.classList.remove('theme-light');
        body.classList.add('theme-dark');
    }
    
    // 保存主题到localStorage
    localStorage.setItem('theme', body.classList.contains('theme-dark') ? 'dark' : 'light');
    
    // 添加旋转动画（支持多个按钮）
    const buttons = [btnToggleThemeCollapsed, btnToggleThemeSidebar];
    buttons.forEach(btn => {
        if (btn) {
            btn.style.transform = 'rotate(360deg)';
            setTimeout(() => {
                btn.style.transform = '';
            }, 300);
        }
    });
}

// 加载保存的主题
function loadTheme() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        body.classList.remove('theme-dark', 'theme-light');
        body.classList.add(savedTheme === 'dark' ? 'theme-dark' : 'theme-light');
    }
}

// 设置输入框自动高度
function setupInputAutoHeight() {
    if (messageInput) {
        messageInput.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 120) + 'px';
        });
    }
}

