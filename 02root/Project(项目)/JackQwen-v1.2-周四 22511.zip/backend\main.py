from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import StreamingResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict
import os
import openai
import httpx
from dotenv import load_dotenv
import database
import json

# 加载环境变量
load_dotenv()

# 初始化FastAPI应用
app = FastAPI(title="AI聊天机器人")

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 配置OpenAI客户端
API_BASE_URL = os.getenv("API_BASE_URL", "https://idealab.alibaba-inc.com/api/openai/v1")
API_KEY = os.getenv("API_KEY", "")
MODEL_NAME = os.getenv("MODEL_NAME", "qwen3-coder-plus")

# 延迟初始化OpenAI客户端，避免启动时错误
client = None

def get_openai_client():
    """获取OpenAI客户端（延迟初始化）"""
    global client
    if client is None:
        try:
            # 使用显式的http_client参数，避免proxies兼容性问题
            # 注意：不在httpx.Client中设置base_url，由OpenAI客户端处理
            http_client = httpx.Client(
                timeout=60.0
            )
            client = openai.OpenAI(
                base_url=API_BASE_URL,
                api_key=API_KEY if API_KEY else "dummy-key",  # 避免空字符串导致错误
                http_client=http_client
            )
        except Exception as e:
            # 如果初始化失败，记录错误但不抛出异常
            print(f"警告: OpenAI客户端初始化失败: {e}")
            print("提示: 请检查.env文件中的API配置")
            raise
    return client

# 启动时初始化数据库
@app.on_event("startup")
async def startup_event():
    database.init_db()
    print("后端服务已启动")

# 请求模型
class ChatRequest(BaseModel):
    session_id: int
    messages: List[Dict[str, str]]
    system_prompt: Optional[str] = None

class SessionCreate(BaseModel):
    title: Optional[str] = "新对话"
    system_prompt: Optional[str] = ""

class SessionUpdate(BaseModel):
    title: Optional[str] = None
    system_prompt: Optional[str] = None

class MessageUpdate(BaseModel):
    content: str

class PromptTemplateCreate(BaseModel):
    name: str
    content: str
    category: Optional[str] = ""

class PromptTemplateUpdate(BaseModel):
    name: Optional[str] = None
    content: Optional[str] = None
    category: Optional[str] = None

# API路由

@app.get("/api/health")
async def health_check():
    """健康检查"""
    return {"status": "ok"}

@app.get("/api/sessions")
async def get_sessions():
    """获取所有会话列表"""
    sessions = database.get_sessions()
    return {"sessions": sessions}

@app.post("/api/sessions")
async def create_session(session_data: SessionCreate):
    """创建新会话"""
    session_id = database.create_session(
        title=session_data.title,
        system_prompt=session_data.system_prompt or ""
    )
    return {"session_id": session_id, "title": session_data.title}

@app.get("/api/sessions/{session_id}")
async def get_session(session_id: int):
    """获取指定会话信息"""
    session = database.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="会话不存在")
    return session

@app.put("/api/sessions/{session_id}")
async def update_session(session_id: int, session_data: SessionUpdate):
    """更新会话信息"""
    session = database.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="会话不存在")
    
    if session_data.title is not None:
        database.update_session_title(session_id, session_data.title)
    if session_data.system_prompt is not None:
        database.update_session_system_prompt(session_id, session_data.system_prompt)
    
    return {"message": "更新成功"}

@app.delete("/api/sessions/{session_id}")
async def delete_session(session_id: int):
    """删除会话"""
    session = database.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="会话不存在")
    database.delete_session(session_id)
    return {"message": "删除成功"}

@app.get("/api/sessions/{session_id}/messages")
async def get_messages(session_id: int):
    """获取指定会话的所有消息"""
    session = database.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="会话不存在")
    messages = database.get_messages(session_id)
    return {"messages": messages}

@app.delete("/api/messages/{message_id}")
async def delete_message(message_id: int):
    """删除指定消息"""
    message = database.get_message(message_id)
    if not message:
        raise HTTPException(status_code=404, detail="消息不存在")
    database.delete_message(message_id)
    return {"message": "删除成功"}

@app.put("/api/messages/{message_id}")
async def update_message(message_id: int, message_data: MessageUpdate):
    """更新指定消息的内容"""
    message = database.get_message(message_id)
    if not message:
        raise HTTPException(status_code=404, detail="消息不存在")
    database.update_message(message_id, message_data.content)
    return {"message": "更新成功"}

# 提示词模板相关API
@app.get("/api/prompt-templates")
async def get_prompt_templates(
    category: Optional[str] = None,
    is_favorite: Optional[bool] = None,
    search: Optional[str] = None,
    sort_by: str = 'created_at'
):
    """获取所有提示词模板，支持分类、收藏、搜索筛选和排序"""
    templates = database.get_prompt_templates(
        category=category,
        is_favorite=is_favorite,
        search=search,
        sort_by=sort_by
    )
    return {"templates": templates}

@app.get("/api/prompt-templates/categories")
async def get_template_categories():
    """获取所有模板分类列表"""
    categories = database.get_template_categories()
    return {"categories": categories}

@app.post("/api/prompt-templates")
async def create_prompt_template(template_data: PromptTemplateCreate):
    """创建提示词模板"""
    template_id = database.create_prompt_template(
        name=template_data.name,
        content=template_data.content,
        category=template_data.category or ""
    )
    return {"template_id": template_id, "message": "创建成功"}

@app.put("/api/prompt-templates/{template_id}")
async def update_prompt_template(template_id: int, template_data: PromptTemplateUpdate):
    """更新提示词模板"""
    template = database.get_prompt_template(template_id)
    if not template:
        raise HTTPException(status_code=404, detail="模板不存在")
    
    database.update_prompt_template(
        template_id=template_id,
        name=template_data.name,
        content=template_data.content,
        category=template_data.category
    )
    return {"message": "更新成功"}

@app.post("/api/prompt-templates/{template_id}/favorite")
async def toggle_template_favorite(template_id: int):
    """切换模板收藏状态"""
    template = database.get_prompt_template(template_id)
    if not template:
        raise HTTPException(status_code=404, detail="模板不存在")
    
    is_favorite = database.toggle_template_favorite(template_id)
    return {"is_favorite": is_favorite, "message": "操作成功"}

@app.post("/api/prompt-templates/{template_id}/use")
async def record_template_use(template_id: int):
    """记录模板使用"""
    template = database.get_prompt_template(template_id)
    if not template:
        raise HTTPException(status_code=404, detail="模板不存在")
    
    database.increment_template_use(template_id)
    return {"message": "使用记录已更新"}

@app.get("/api/prompt-templates/{template_id}")
async def get_prompt_template(template_id: int):
    """获取指定提示词模板"""
    template = database.get_prompt_template(template_id)
    if not template:
        raise HTTPException(status_code=404, detail="模板不存在")
    return template

@app.delete("/api/prompt-templates/{template_id}")
async def delete_prompt_template(template_id: int):
    """删除提示词模板"""
    template = database.get_prompt_template(template_id)
    if not template:
        raise HTTPException(status_code=404, detail="模板不存在")
    database.delete_prompt_template(template_id)
    return {"message": "删除成功"}

@app.post("/api/chat")
async def chat(request: ChatRequest):
    """流式聊天接口"""
    # 获取会话信息
    session = database.get_session(request.session_id)
    if not session:
        raise HTTPException(status_code=404, detail="会话不存在")
    
    # 获取历史消息
    history_messages = database.get_messages(request.session_id)
    
    # 构建消息列表
    messages = []
    
    # 添加system prompt（优先使用请求中的，否则使用会话中的）
    system_prompt = request.system_prompt or session.get("system_prompt", "")
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    
    # 添加历史消息
    for msg in history_messages:
        messages.append({
            "role": msg["role"],
            "content": msg["content"]
        })
    
    # 添加新消息
    messages.extend(request.messages)
    
    # 更新system prompt（如果请求中有新的）
    if request.system_prompt is not None and request.system_prompt != session.get("system_prompt", ""):
        database.update_session_system_prompt(request.session_id, request.system_prompt)
    
    async def generate():
        """生成流式响应"""
        full_response = ""
        user_message = ""
        
        # 提取用户消息内容（用于保存）
        for msg in request.messages:
            if msg["role"] == "user":
                user_message += msg["content"] + "\n"
        
        try:
            # 获取OpenAI客户端
            openai_client = get_openai_client()
            
            # 调用OpenAI API（流式）
            stream = openai_client.chat.completions.create(
                model=MODEL_NAME,
                messages=messages,
                stream=True
            )
            
            for chunk in stream:
                if chunk.choices[0].delta.content:
                    content = chunk.choices[0].delta.content
                    full_response += content
                    # 发送数据块
                    yield f"data: {json.dumps({'content': content}, ensure_ascii=False)}\n\n"
            
            # 流式传输结束，发送结束标记
            yield "data: [DONE]\n\n"
            
            # 保存消息到数据库
            if user_message.strip():
                database.add_message(request.session_id, "user", user_message.strip())
            if full_response.strip():
                database.add_message(request.session_id, "assistant", full_response.strip())
            
            # 如果这是第一次对话，自动更新对话标题
            if database.should_update_title(request.session_id):
                first_user_msg = database.get_first_user_message(request.session_id)
                if first_user_msg:
                    # 提取前30个字符作为标题，去除换行和多余空格
                    title = first_user_msg.strip().replace('\n', ' ').replace('\r', ' ')
                    if len(title) > 30:
                        title = title[:30] + '...'
                    database.update_session_title(request.session_id, title)
                
        except Exception as e:
            error_msg = f"错误: {str(e)}"
            yield f"data: {json.dumps({'error': error_msg}, ensure_ascii=False)}\n\n"
            yield "data: [DONE]\n\n"
    
    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"
        }
    )

# 静态文件服务
frontend_path = os.path.join(os.path.dirname(__file__), '..', 'frontend')

@app.get("/")
async def read_root():
    """返回前端首页"""
    index_path = os.path.join(frontend_path, 'index.html')
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "前端文件未找到"}

@app.get("/debug")
async def debug_page():
    """调试页面"""
    debug_path = os.path.join(frontend_path, 'debug.html')
    if os.path.exists(debug_path):
        return FileResponse(debug_path)
    return {"message": "调试页面未找到"}

# 挂载静态文件目录
if os.path.exists(frontend_path):
    app.mount("/static", StaticFiles(directory=frontend_path), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

