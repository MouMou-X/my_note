import sqlite3
import os
from datetime import datetime
from typing import List, Dict, Optional

# 数据库文件路径
DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'app.db')

def get_db_connection():
    """获取数据库连接"""
    # 确保data目录存在
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # 使结果可以作为字典访问
    return conn

def init_db():
    """初始化数据库，创建表"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # 创建sessions表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            system_prompt TEXT DEFAULT '',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 创建messages表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER,
            role TEXT,
            content TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(session_id) REFERENCES sessions(id)
        )
    ''')
    
    # 创建prompt_templates表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS prompt_templates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            content TEXT NOT NULL,
            category TEXT DEFAULT '',
            is_favorite INTEGER DEFAULT 0,
            use_count INTEGER DEFAULT 0,
            last_used_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 自动迁移：检查并添加新字段（如果表已存在但缺少新字段）
    try:
        cursor.execute('PRAGMA table_info(prompt_templates)')
        columns = [row[1] for row in cursor.fetchall()]
        
        if 'category' not in columns:
            cursor.execute('ALTER TABLE prompt_templates ADD COLUMN category TEXT DEFAULT ""')
        if 'is_favorite' not in columns:
            cursor.execute('ALTER TABLE prompt_templates ADD COLUMN is_favorite INTEGER DEFAULT 0')
        if 'use_count' not in columns:
            cursor.execute('ALTER TABLE prompt_templates ADD COLUMN use_count INTEGER DEFAULT 0')
        if 'last_used_at' not in columns:
            cursor.execute('ALTER TABLE prompt_templates ADD COLUMN last_used_at TIMESTAMP')
    except Exception as e:
        print(f"数据库迁移警告: {e}")
    
    # 如果表是新建的，插入一些默认模板
    cursor.execute('SELECT COUNT(*) FROM prompt_templates')
    if cursor.fetchone()[0] == 0:
        default_templates = [
            ('通用助手', '你是一个有用的AI助手，能够回答各种问题并提供帮助。', '通用', 0, 0, None),
            ('代码助手', '你是一个专业的编程助手，擅长编写、调试和优化代码。请提供清晰、准确的代码建议。', '专业', 0, 0, None),
            ('翻译助手', '你是一个专业的翻译助手，能够准确地将文本翻译成各种语言。', '工具', 0, 0, None),
            ('写作助手', '你是一个专业的写作助手，能够帮助用户撰写、修改和优化各种类型的文本。', '创作', 0, 0, None),
        ]
        cursor.executemany('''
            INSERT INTO prompt_templates (name, content, category, is_favorite, use_count, last_used_at) 
            VALUES (?, ?, ?, ?, ?, ?)
        ''', default_templates)
    
    conn.commit()
    conn.close()
    print(f"数据库初始化完成: {DB_PATH}")

def create_session(title: str = "新对话", system_prompt: str = "") -> int:
    """创建新会话，返回会话ID"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO sessions (title, system_prompt) 
        VALUES (?, ?)
    ''', (title, system_prompt))
    session_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return session_id

def get_sessions() -> List[Dict]:
    """获取所有会话列表"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT id, title, system_prompt, created_at 
        FROM sessions 
        ORDER BY created_at DESC
    ''')
    sessions = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return sessions

def get_session(session_id: int) -> Optional[Dict]:
    """获取指定会话信息"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT id, title, system_prompt, created_at 
        FROM sessions 
        WHERE id = ?
    ''', (session_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def update_session_title(session_id: int, title: str):
    """更新会话标题"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE sessions 
        SET title = ? 
        WHERE id = ?
    ''', (title, session_id))
    conn.commit()
    conn.close()

def update_session_system_prompt(session_id: int, system_prompt: str):
    """更新会话的system prompt"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE sessions 
        SET system_prompt = ? 
        WHERE id = ?
    ''', (system_prompt, session_id))
    conn.commit()
    conn.close()

def add_message(session_id: int, role: str, content: str):
    """向messages表添加消息"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO messages (session_id, role, content) 
        VALUES (?, ?, ?)
    ''', (session_id, role, content))
    conn.commit()
    conn.close()

def get_messages(session_id: int) -> List[Dict]:
    """获取指定会话的所有消息"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT id, session_id, role, content, created_at 
        FROM messages 
        WHERE session_id = ? 
        ORDER BY created_at ASC
    ''', (session_id,))
    messages = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return messages

def delete_session(session_id: int):
    """删除会话及其所有消息"""
    conn = get_db_connection()
    cursor = conn.cursor()
    # 先删除消息
    cursor.execute('DELETE FROM messages WHERE session_id = ?', (session_id,))
    # 再删除会话
    cursor.execute('DELETE FROM sessions WHERE id = ?', (session_id,))
    conn.commit()
    conn.close()

def delete_message(message_id: int):
    """删除指定消息"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM messages WHERE id = ?', (message_id,))
    conn.commit()
    conn.close()

def update_message(message_id: int, content: str):
    """更新指定消息的内容"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE messages 
        SET content = ? 
        WHERE id = ?
    ''', (content, message_id))
    conn.commit()
    conn.close()

def get_message(message_id: int) -> Optional[Dict]:
    """获取指定消息"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT id, session_id, role, content, created_at 
        FROM messages 
        WHERE id = ?
    ''', (message_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def get_first_user_message(session_id: int) -> Optional[str]:
    """获取会话中第一条用户消息"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT content 
        FROM messages 
        WHERE session_id = ? AND role = 'user'
        ORDER BY created_at ASC
        LIMIT 1
    ''', (session_id,))
    row = cursor.fetchone()
    conn.close()
    return row[0] if row else None

def should_update_title(session_id: int) -> bool:
    """检查是否需要更新标题（标题还是"新对话"且已有用户消息）"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT title, (SELECT COUNT(*) FROM messages WHERE session_id = sessions.id AND role = 'user') as user_message_count
        FROM sessions
        WHERE id = ?
    ''', (session_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        title = row[0]
        user_message_count = row[1]
        # 如果标题还是"新对话"且只有一条用户消息（刚添加的第一条），则更新标题
        return title == "新对话" and user_message_count == 1
    return False

# 提示词模板相关函数
def get_prompt_templates(category: Optional[str] = None, is_favorite: Optional[bool] = None, search: Optional[str] = None, sort_by: str = 'created_at') -> List[Dict]:
    """获取所有提示词模板，支持分类、收藏、搜索筛选和排序"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    query = 'SELECT id, name, content, category, is_favorite, use_count, last_used_at, created_at FROM prompt_templates WHERE 1=1'
    params = []
    
    if category:
        query += ' AND category = ?'
        params.append(category)
    
    if is_favorite is not None:
        query += ' AND is_favorite = ?'
        params.append(1 if is_favorite else 0)
    
    if search:
        query += ' AND (name LIKE ? OR content LIKE ?)'
        search_pattern = f'%{search}%'
        params.extend([search_pattern, search_pattern])
    
    # 排序（SQLite不支持NULLS LAST，使用CASE处理）
    if sort_by == 'last_used_at':
        query += ' ORDER BY CASE WHEN last_used_at IS NULL THEN 1 ELSE 0 END, last_used_at DESC, created_at DESC'
    elif sort_by == 'use_count':
        query += ' ORDER BY use_count DESC, created_at DESC'
    elif sort_by == 'name':
        query += ' ORDER BY name ASC'
    else:  # created_at (default)
        query += ' ORDER BY created_at DESC'
    
    cursor.execute(query, params)
    templates = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return templates

def create_prompt_template(name: str, content: str, category: str = '') -> int:
    """创建提示词模板，返回模板ID"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO prompt_templates (name, content, category) 
        VALUES (?, ?, ?)
    ''', (name, content, category))
    template_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return template_id

def update_prompt_template(template_id: int, name: Optional[str] = None, content: Optional[str] = None, category: Optional[str] = None):
    """更新提示词模板"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    updates = []
    params = []
    
    if name is not None:
        updates.append('name = ?')
        params.append(name)
    if content is not None:
        updates.append('content = ?')
        params.append(content)
    if category is not None:
        updates.append('category = ?')
        params.append(category)
    
    if updates:
        params.append(template_id)
        query = f'UPDATE prompt_templates SET {", ".join(updates)} WHERE id = ?'
        cursor.execute(query, params)
        conn.commit()
    
    conn.close()

def toggle_template_favorite(template_id: int) -> bool:
    """切换模板收藏状态，返回新的收藏状态"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT is_favorite FROM prompt_templates WHERE id = ?', (template_id,))
    row = cursor.fetchone()
    if row:
        new_favorite = 1 if row[0] == 0 else 0
        cursor.execute('UPDATE prompt_templates SET is_favorite = ? WHERE id = ?', (new_favorite, template_id))
        conn.commit()
        conn.close()
        return new_favorite == 1
    conn.close()
    return False

def increment_template_use(template_id: int):
    """增加模板使用次数并更新最后使用时间"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE prompt_templates 
        SET use_count = use_count + 1, 
            last_used_at = CURRENT_TIMESTAMP 
        WHERE id = ?
    ''', (template_id,))
    conn.commit()
    conn.close()

def delete_prompt_template(template_id: int):
    """删除提示词模板"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM prompt_templates WHERE id = ?', (template_id,))
    conn.commit()
    conn.close()

def get_prompt_template(template_id: int) -> Optional[Dict]:
    """获取指定提示词模板"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT id, name, content, category, is_favorite, use_count, last_used_at, created_at 
        FROM prompt_templates 
        WHERE id = ?
    ''', (template_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def get_template_categories() -> List[str]:
    """获取所有模板分类列表"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT DISTINCT category FROM prompt_templates WHERE category IS NOT NULL AND category != "" ORDER BY category')
    categories = [row[0] for row in cursor.fetchall()]
    conn.close()
    return categories

