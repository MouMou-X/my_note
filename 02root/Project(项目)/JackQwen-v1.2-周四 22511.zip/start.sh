#!/bin/bash

# AI聊天机器人启动脚本

echo "=========================================="
echo "AI聊天机器人启动脚本"
echo "=========================================="

# 检查虚拟环境是否存在
if [ ! -d "venv" ]; then
    echo "❌ 虚拟环境不存在，正在创建..."
    python3 -m venv venv
    echo "✓ 虚拟环境创建完成"
fi

# 激活虚拟环境
echo "📦 激活虚拟环境..."
source venv/bin/activate

# 检查依赖是否已安装
if ! python -c "import fastapi" 2>/dev/null; then
    echo "📥 安装依赖包..."
    pip install -r backend/requirements.txt
    echo "✓ 依赖安装完成"
else
    echo "✓ 依赖已安装"
fi

# 检查.env文件
if [ ! -f "backend/.env" ]; then
    echo ""
    echo "⚠️  警告: backend/.env 文件不存在！"
    echo "请创建 backend/.env 文件，内容如下："
    echo ""
    echo "API_BASE_URL=https://idealab.alibaba-inc.com/api/openai/v1"
    echo "API_KEY=sk-你的实际API密钥"
    echo "MODEL_NAME=qwen3-coder-plus"
    echo ""
    read -p "是否现在创建.env文件？(y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "请输入API密钥:"
        read -r API_KEY
        cat > backend/.env << EOF
API_BASE_URL=https://idealab.alibaba-inc.com/api/openai/v1
API_KEY=$API_KEY
MODEL_NAME=qwen3-coder-plus
EOF
        echo "✓ .env文件已创建"
    else
        echo "请手动创建.env文件后再启动服务器"
        exit 1
    fi
fi

# 检查端口是否被占用
PORT=8000
if lsof -Pi :$PORT -sTCP:LISTEN -t >/dev/null 2>&1 ; then
    echo ""
    echo "⚠️  端口 $PORT 已被占用"
    PID=$(lsof -ti:$PORT)
    echo "占用进程ID: $PID"
    read -p "是否终止该进程并继续启动？(y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        kill -9 $PID 2>/dev/null
        sleep 1
        echo "✓ 已终止占用端口的进程"
    else
        echo "请手动终止占用端口的进程，或使用其他端口启动"
        exit 1
    fi
fi

# 启动服务器
echo ""
echo "🚀 启动服务器..."
echo "服务器地址: http://localhost:$PORT"
echo "API文档: http://localhost:$PORT/docs"
echo "按 Ctrl+C 停止服务器"
echo "=========================================="
echo ""

cd backend
uvicorn main:app --host 0.0.0.0 --port $PORT --reload

