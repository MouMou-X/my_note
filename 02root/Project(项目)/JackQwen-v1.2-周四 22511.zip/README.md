# AI聊天机器人

一个基于 FastAPI 和原生前端技术的本地 AI 聊天机器人网页应用。

## 功能特性

- 🤖 **AI模型接入**：调用私有云模型，API格式与OpenAI SDK兼容
- 💬 **流式输出**：实时显示AI回复，提升用户体验
- 📝 **连续对话**：支持上下文记忆，保持对话连贯性
- 📚 **多会话管理**：类似ChatGPT的侧边栏会话列表
- 💾 **历史记录**：对话历史自动保存到本地SQLite数据库
- 🎨 **Markdown渲染**：AI返回的Markdown格式文本自动渲染成富文本
- ⚙️ **自定义Prompt**：支持用户自定义system prompt
- 🌐 **简体中文界面**：友好的中文用户界面

## 技术栈

- **后端**：Python 3.11+, FastAPI
- **前端**：原生 HTML, CSS, JavaScript（无框架）
- **数据库**：SQLite

## 项目结构

```
chatui/
├── backend/              # 后端代码
│   ├── main.py          # FastAPI主服务
│   ├── database.py      # 数据库模块
│   ├── requirements.txt # Python依赖
│   └── .env            # 环境变量配置（需要自行创建）
├── frontend/            # 前端代码
│   ├── index.html      # 主页面
│   ├── style.css       # 样式文件
│   └── script.js       # JavaScript逻辑
├── data/                # 数据库文件存放处
│   └── app.db          # SQLite数据库（自动生成）
└── README.md           # 项目说明文档
```

## 安装步骤

### 1. 环境准备

确保已安装 Python 3.11 或更高版本。

### 2. 创建虚拟环境

```bash
cd chatui
python -m venv venv
```

**Windows:**
```bash
.\venv\Scripts\activate
```

**macOS/Linux:**
```bash
source venv/bin/activate
```

### 3. 安装依赖

```bash
cd backend
pip install -r requirements.txt
```

### 4. 配置环境变量

在 `backend` 目录下创建 `.env` 文件，内容如下：

```env
API_BASE_URL=https://idealab.alibaba-inc.com/api/openai/v1
API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxx
MODEL_NAME=qwen3-coder-plus
```

**注意**：请将 `API_KEY` 替换为你的实际API密钥。

## 运行项目

### 启动后端服务

```bash
cd backend
uvicorn main:app --reload
```

服务将在 `http://localhost:8000` 启动。

### 访问前端

打开浏览器，访问 `http://localhost:8000` 即可使用聊天机器人。

## API接口说明

### 会话管理

- `GET /api/sessions` - 获取所有会话列表
- `POST /api/sessions` - 创建新会话
- `GET /api/sessions/{session_id}` - 获取指定会话信息
- `PUT /api/sessions/{session_id}` - 更新会话信息
- `DELETE /api/sessions/{session_id}` - 删除会话
- `GET /api/sessions/{session_id}/messages` - 获取指定会话的所有消息

### 聊天接口

- `POST /api/chat` - 流式聊天接口（Server-Sent Events）

**请求体示例：**
```json
{
  "session_id": 1,
  "messages": [
    {
      "role": "user",
      "content": "你好"
    }
  ],
  "system_prompt": "你是一个有用的AI助手"
}
```

## 使用说明

1. **新建会话**：点击左侧边栏的"新建聊天"按钮
2. **切换会话**：点击侧边栏中的任意会话项
3. **自定义Prompt**：在顶部输入框输入system prompt，点击"保存"按钮
4. **发送消息**：
   - 在底部输入框输入消息
   - 点击"发送"按钮或按 `Enter` 键发送
   - 按 `Shift+Enter` 换行
5. **查看历史**：切换会话时，会自动加载该会话的历史消息

## 注意事项

- 首次运行会自动创建数据库文件 `data/app.db`
- 请确保 `.env` 文件中的API密钥正确
- 建议不要将 `.env` 文件提交到代码仓库
- 数据库文件会自动保存所有对话历史

## 故障排除

### 问题：无法连接到API

- 检查 `.env` 文件中的 `API_BASE_URL` 和 `API_KEY` 是否正确
- 确认网络连接正常

### 问题：前端页面无法显示

- 确认后端服务已启动（`http://localhost:8000`）
- 检查浏览器控制台是否有错误信息

### 问题：数据库相关错误

- 确认 `data` 目录存在且有写入权限
- 删除 `data/app.db` 文件后重新启动服务（会重新创建数据库）

## 开发说明

本项目采用前后端分离架构：

- **后端**：FastAPI提供RESTful API和静态文件服务
- **前端**：纯原生HTML/CSS/JavaScript，无框架依赖
- **数据库**：SQLite存储会话和消息数据

## 许可证

本项目仅供学习和个人使用。

